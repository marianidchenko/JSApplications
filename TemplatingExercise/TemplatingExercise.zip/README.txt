Imports are intended to be in non-nested folder from node_modules change import paths for lit-html if needed.
