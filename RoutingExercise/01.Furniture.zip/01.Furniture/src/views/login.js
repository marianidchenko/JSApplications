import { html } from '../library.js';
import * as api from '../api/data.js';

const loginTempalte = (onSubmit, errorMsg) => html`
<div class="row space-top">
    <div class="col-md-12">
        <h1>Login User</h1>
        <p>Please fill all fields.</p>
    </div>
</div>
<form @submit=${onSubmit}>
    <div class="row space-top">
        <div class="col-md-4">
            ${errorMsg ? html`<div class='form-group'>${errorMsg}</div>`: null}
            <div class="form-group">
                <label class="form-control-label" for="email">Email</label>
                <input class=${"form-control" + ' ' + (errorMsg ? 'is-invalid': 'is-valid')} id="email" type="text" name="email">
            </div>
            <div class="form-group">
                <label class="form-control-label" for="password">Password</label>
                <input class=${"form-control" + ' ' + (errorMsg ? 'is-invalid': 'is-valid')} id="password" type="password" name="password">
            </div>
            <input type="submit" class="btn btn-primary" value="Login" />
        </div>
    </div>
</form>`

export function loginPage(ctx) {
    update();

    function update(errorMsg) {
        ctx.render(loginTempalte(onSubmit, errorMsg));
    }

    async function onSubmit(event) {
        event.preventDefault();
        const formData = new FormData(event.target);

        const email = formData.get('email');
        const password = formData.get('password');
        try{
            await api.login(email, password);
            ctx.updateUserNav();
            ctx.page.redirect('/');
        } catch(err) {
            update(err.message)
        }
        
    }
}